# x = "awesome"
# def myfunc():
#   global x 
#   x = 'python is fantastic'
#   print("Python is " + x)
     
# myfunc()

# print("Python is " + x) 

# x = bytearray(5)
# print(x)

# import random
# print(random.randrange(1,10))
# a = "Pakistan's Capital   Islamabad"
# print('is'not in a)

# def myFunction() :
#   return False

# if myFunction():
#   print("YES!")
# else:
#   print("NO!") 

# thislist = ["apple", "banana", "cherry"]
# thislist[1:3] = ["blackcurrant"]
# print(thislist) 

# lst = ['apple','Kiwi','Orange']
# for list in range(len(lst)):
#     print(lst[list])

# lst = ['apple','Kiwi','Orange']
# i = 0
# while i < len(lst):
#     print(lst[i])
    # i+=1

# lst = ['apple','Kiwi','Orange']
# # [print(x,end=',') for x in lst ]

# thislist = ["banana", "Orange", "Kiwi", "cherry"]
# thislist2 = ["nana", "Oe", "Kii", "rry"]
# for x in thislist2:
#     thislist.append(x)
# print(thislist)

# list1 = ["a", "b" , "c"]
# list2 = [1, 2, 3] 
# for x in list2:
#   list1.append(x)
# print(list1) 

lst = ['Apple','Kiwi','orange','watermelon']
# tup = list(lst)
# tup[0]='banana'
# lst1 = tuple(tup)
# print(lst1)
# l1 = list(lst)
# l1.append('orange')
# tup = list(l1)
# print(tup)

# lst = ['Apple','Kiwi','orange','watermelon']
# y = ('orange',)
# lst+=y
# print(lst)

# lst = ['Apple','Kiwi','orange','watermelon']
# (apple,bic,ca,d) = lst
# print(apple)
# print(bic)
# print(ca)
# print(d)

fruits = ("apple", "mango", "papaya", "pineapple", "cherry")

(*green, tropic, red) = fruits

print(green)
print(tropic)
print(red)