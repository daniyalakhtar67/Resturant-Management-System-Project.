try:
    x=int(input("Enter a no: "))
    y=int(input("Enter no 2: "))
    sum = x+y
    d=x/y
except ValueError:
    print("Invalid value")
except ArithmeticError:
    print("Invalid value in denominator")
else:
    print("sum is",sum)
    print(x, "/", y, "=", d)